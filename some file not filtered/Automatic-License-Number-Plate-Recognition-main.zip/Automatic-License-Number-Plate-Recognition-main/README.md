# Automatic-License-Number-Plate-Recognition
This project aims to recognize license number plates, the project could be useful for security, monitoring, e-challan, etc. In order to detect license number plates, we will use OpenCV to identify number plates and python pytesseract to extract characters and digits from the number plates.
Automatic License Number Plate Detection and Recognition
This project aims to recognize license number plates, the project could be useful for security, monitoring, e-challan, etc. In order to detect license number plates, we will use OpenCV to identify number plates and python pytesseract to extract characters and digits from the number plates.

OpenCV is an open-source machine learning library and provides a common infrastructure for computer vision. Whereas Pytesseract is a Tesseract-OCR Engine to read image types and extract the information present in the image.


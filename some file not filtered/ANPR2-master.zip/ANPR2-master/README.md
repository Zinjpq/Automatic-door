ANPR2
=====

Automatic number plate recognition

![1](https://raw.githubusercontent.com/hoangkianh/ANPR2/master/Screenshot/Image%201.png "Screenshot")

![2](https://raw.githubusercontent.com/hoangkianh/ANPR2/master/Screenshot/Image%202.png "Screenshot")

![3](https://raw.githubusercontent.com/hoangkianh/ANPR2/master/Screenshot/Image%203.png "Screenshot")

![4](https://raw.githubusercontent.com/hoangkianh/ANPR2/master/Screenshot/Image%204.png "Screenshot")

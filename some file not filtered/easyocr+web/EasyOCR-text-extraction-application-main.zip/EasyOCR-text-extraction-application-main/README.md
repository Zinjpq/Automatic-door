# EasyOCR-text-extraction-application
Flask web application for text extraction using EasyOCR.
